package com.tools;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

import com.common.User;
import com.util.StringNull;

/**
 * �û�ע����Ϣ
 * @author admin
 *
 */
public class UserDao {
	/**
	 * �û�ע��
	 * @param con
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public int register(Connection con,User user) throws Exception{
		String sql = "insert into user values(?,?,?,?)";
		PreparedStatement pstmt = (PreparedStatement)con.prepareStatement(sql);
		pstmt.setString(1, user.getUserId());
		pstmt.setString(4, user.getPasswd());
		return pstmt.executeUpdate();
	}
	/**
	 * �û���Ϣ����,�����ã��û�id������ͬ
	 * @param con
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public User login(Connection con,User user) throws Exception{
//		JOptionPane.showMessageDialog(null,"zhuce");
//		JOptionPane.showMessageDialog(null,user.getUser_id());
		User resultUser = null;
		String sql ="select * from user where userId=? and passwd=?";
		PreparedStatement pstmt = (PreparedStatement)con.prepareStatement(sql);
		pstmt.setString(1, user.getUserId());
		pstmt.setString(2, user.getPasswd());
		//pstmt.setString(3, user.getName());
		//pstmt.setString(4, user.getPhone());
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			resultUser = new User();
			resultUser.setUserId(rs.getString("userId"));
		
			resultUser.setPasswd(rs.getString("passwd"));
			resultUser.setName(rs.getString("name"));
			resultUser.setPhone(rs.getString("phone"));
		}
//		JOptionPane.showMessageDialog(null, "�ڷ��������ҵ������Ϣ");
//		JOptionPane.showMessageDialog(null, "���������"+resultUser.getName());
		return resultUser;
	}
	
	
	
	/**
	 * ��ѯ�û�
	 * @param con
	 * @param book
	 * @return
	 * @throws Exception
	 */
	public ResultSet query2(Connection con,User user)throws Exception{
		ResultSet resultUser = null;
		String sql = "select * from user where user_id=?";
		PreparedStatement pstmt = (PreparedStatement)con.prepareStatement(sql);
		
		pstmt.setString(1,user.getUserId());
		
		return pstmt.executeQuery();
	}
	/**
	 * ��ѯ
	 * @param con
	 * @param book
	 * @return
	 * @throws Exception
	 */
	public ResultSet query3(Connection con,User user)throws Exception{
		ResultSet resultUser = null;
		StringBuffer sql = new StringBuffer("select * from user");
		// String userIdStr = user.getUser_id().getText().toString();
		//���ݿ�ģ����ѯ
		if(StringNull.isNotEmpty(user.getUserId())) {
			sql.append(" and user_id like '%"+user.getUserId()+"%'");
		}
		
		
		if(StringNull.isNotEmpty(user.getPasswd())) {
			sql.append(" and book_publish like '%"+user.getPasswd()+"%'");
		}
		
		PreparedStatement pstmt = (PreparedStatement)con.prepareStatement(sql.toString().replaceFirst("and", "where"));
		return pstmt.executeQuery(); 
	}
	
	
	
	
	/**
	 * ͨ���û�Id��ѯ�û�������Ϣ
	 * @param con
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public ResultSet query(Connection con, int userId)throws Exception{
		String sql = "select * from user where user_id = ?";
		PreparedStatement pstmt = (PreparedStatement)con.prepareStatement(sql);
		pstmt.setInt(1, userId);
		return pstmt.executeQuery();
	}
	/**
	 * ɾ���û�
	 * @param con
	 * @param userId
	 * @return
	 * @throws Exception
	 */
//	public int delete(Connection con, int userId)throws Exception{
//		String sql = "delete from user where user_id = ?";
//		PreparedStatement pstmt = (PreparedStatement)con.prepareStatement(sql);
//		pstmt.setInt(1, userId);
//		return pstmt.executeUpdate();
//	}
//	
//	
//	public int add(Connection con, User user)throws Exception{
//		String sql  = "insert into user values(?,?,?,?)";
//		PreparedStatement pstmt = (PreparedStatement)con.prepareStatement(sql);
//		
//		pstmt.setInt(1, user.getUser_id());
//		pstmt.setString(2, user.getUser_name());
//		pstmt.setString(3, user.getUser_phone());
//		pstmt.setString(4,  user.getUser_password());
//		
//		
//		return pstmt.executeUpdate();
//	}
//	
	
	
	
	

	
}
