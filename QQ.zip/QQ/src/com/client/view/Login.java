package com.client.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.client.model.Client_Con_Sever;
import com.client.tools.Manage_ClientConServer_Thread;
import com.common.Message;
import com.common.MessageType;
import com.common.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Login extends JFrame {
	

	private JPanel contentPane;
	private JTextField idTxt;
	private JPasswordField passwdfd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("QQ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//	    Image image = Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("image/qq.png"));
//	    this.setIconImage(image);
		
		// Image frame_icon=Toolkit.getDefaultToolkit().createImage(Main.class.getResource("yobbo.png")); this.setIconImage(frame_icon);
		this.setIconImage(new ImageIcon("image/qq.png").getImage());  
		
		setBounds(100, 100, 543, 388);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("\u627E\u56DE\u5BC6\u7801");
		lblNewLabel_3.setBounds(322, 270, 58, 15);
		contentPane.add(lblNewLabel_3);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("\u8BB0\u4F4F\u5BC6\u7801");
		rdbtnNewRadioButton_1.setBackground(Color.WHITE);
		rdbtnNewRadioButton_1.setBounds(224, 266, 78, 23);
		contentPane.add(rdbtnNewRadioButton_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(5, 5, 519, 158);
		lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/image/QQ\u56FE\u724720201119211258.png")));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Login.class.getResource("/image/\u7528\u62371.png")));
		lblNewLabel_1.setBounds(132, 169, 86, 48);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(Login.class.getResource("/image/\u5BC6\u7801.png")));
		lblNewLabel_2.setBounds(130, 215, 34, 30);
		contentPane.add(lblNewLabel_2);
		
		idTxt = new JTextField();
		idTxt.setBounds(189, 182, 191, 23);
		contentPane.add(idTxt);
		idTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Loginaction();
			}
		});
		btnNewButton.setIcon(new ImageIcon(Login.class.getResource("/image/\u767B\u5165.png")));
		btnNewButton.setBounds(151, 303, 247, 38);
		contentPane.add(btnNewButton);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("\u81EA\u52A8\u767B\u5165");
		rdbtnNewRadioButton.setBackground(Color.WHITE);
		rdbtnNewRadioButton.setBounds(130, 266, 78, 23);
		contentPane.add(rdbtnNewRadioButton);
		
		JButton btnNewButton_1 = new JButton("\u6CE8\u518C\u8D26\u53F7");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.setBounds(0, 318, 97, 23);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.setContentAreaFilled(false);
		btnNewButton_1.setBorderPainted(false);
		
		passwdfd = new JPasswordField();
		passwdfd.setBounds(189, 222, 191, 23);
		contentPane.add(passwdfd);
		this.setLocationRelativeTo(null);//������ʾ
	}

	protected void Loginaction() {
		// TODO �Զ����ɵķ������
		//QqClientUser qqClientUser=new QqClientUser();
		User u=new User();
		u.setUserId(idTxt.getText().trim());
		u.setPasswd(new String(passwdfd.getPassword()));
		
		Client_Con_Sever ccsr=new Client_Con_Sever();
		boolean mes=ccsr.sendLoginInfoToServer(u);
		u=ccsr.user;
		
		if(mes)
		{
			JOptionPane.showMessageDialog(null, "����ɹ�,���ڼ��ؽ���....");
			try 
			{
//				//�Ѵ��������б��������ǰ.
//				//�򿪺����б���ʱ�� ���Լ���ID����ȥ
			//	Friendwindow qqList=new Friendwindow(u.getUserId());
				Friendwindow qqList=new Friendwindow(u.getUserId(),u.getName());
				qqList.setVisible(true);
//				ManageQqFriendList.addQqFriendList(u.getUserId(), qqList);
//				
//				//����һ��Ҫ�󷵻����ߺ��ѵ������.
				ObjectOutputStream oos=new ObjectOutputStream
				(Manage_ClientConServer_Thread.getClientConServerThread(u.getUserId()).getS().getOutputStream());
//				
//				//��һ��Message
				Message m=new Message();
				m.setMesType(MessageType.message_get_onLineFriend);
//				//ָ����Ҫ�������qq�ŵĺ������.
				m.setSender(u.getUserId());
				oos.writeObject(m);
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				// TODO: handle exception
			}
			
			//�رյ���¼����
			this.dispose();
		}else{
			JOptionPane.showMessageDialog(this,"�û������������");
		}
	}
}
