package com.client.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.client.tools.Manage_ClientConServer_Thread;
import com.common.Message;
import com.common.MessageType;

import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.ObjectOutputStream;

public class Chat extends JFrame {
	//public Message m=new Message();
	private JPanel contentPane;
	private JTextField jtf;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Chat frame = new Chat("", "   С��","");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param friendNo 
	 * @param owner 
	 */
	JTextArea jta;
	String ownerId;
	String friendId;
	Message mc=new Message();
	
	public Chat(String owner, String friendNo,String friendid) {//m
		setResizable(false);
		setFont(new Font("������", Font.BOLD, 23));
		this.ownerId=owner;
		this.friendId=friendid;
		setForeground(new Color(0, 0, 0));
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(Chat.class.getResource("/image/\u7528\u6237.png")));
		setTitle("                                                              "+friendNo);
		
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 554, 521);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 545, 484);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(175, 0, 370, 36);
		panel.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(Chat.class.getResource("/image/lt.png")));
		
	    jta = new JTextArea();
		jta.setBackground(new Color(255, 255, 255));
		jta.setBounds(0, 36, 535, 254);
		panel.add(jta);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Chat.class.getResource("/image/lt2.png")));
		lblNewLabel_1.setBounds(0, 288, 535, 26);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\u5173\u95ED");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setBounds(359, 454, 83, 26);
		panel.add(btnNewButton);
		
		jtf = new JTextField();
		jtf.setBackground(new Color(255, 255, 255));
		jtf.setBounds(0, 324, 545, 130);
		panel.add(jtf);
		jtf.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("\u53D1\u9001");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				sentClicked(e);
			}
		});
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.setBounds(452, 454, 83, 26);
		panel.add(btnNewButton_1);
		this.setLocationRelativeTo(null);//������ʾ
	}
	
	public Chat(Message m) {
		JOptionPane.showMessageDialog(null, "��ʾ:"+m.getSname()+m.getSender()+"Ҫ��"+m.getGname()+m.getGetter()+"��Ϣ"+m.getCon());
		// TODO �Զ����ɵĹ��캯�����
		setResizable(false);
		setFont(new Font("������", Font.BOLD, 23));
		this.ownerId=m.getSender();
		mc.setSender(m.getSender());
		//this.friendId=friendid;
		mc.setGetter(m.getGetter());
		mc.setGname(m.getGname());
		mc.setSname(m.getSname());
		setForeground(new Color(0, 0, 0));
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(Chat.class.getResource("/image/\u7528\u6237.png")));
		setTitle("                                                              "+mc.getGname());
		
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 554, 521);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 545, 484);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(175, 0, 370, 36);
		panel.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(Chat.class.getResource("/image/lt.png")));
		
	    jta = new JTextArea();
		jta.setBackground(new Color(255, 255, 255));
		jta.setBounds(0, 36, 535, 254);
		panel.add(jta);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Chat.class.getResource("/image/lt2.png")));
		lblNewLabel_1.setBounds(0, 288, 535, 26);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\u5173\u95ED");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setBounds(359, 454, 83, 26);
		panel.add(btnNewButton);
		
		jtf = new JTextField();
		jtf.setBackground(new Color(255, 255, 255));
		jtf.setBounds(0, 324, 545, 130);
		panel.add(jtf);
		jtf.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("\u53D1\u9001");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				sentClicked(e);
			}
		});
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.setBounds(452, 454, 83, 26);
		panel.add(btnNewButton_1);
		this.setLocationRelativeTo(null);//������ʾ
	}
	/**
	 * ���Ͱ�ť
	 * @param e
	 */
	protected void sentClicked(MouseEvent e) {
		// TODO �Զ����ɵķ������
		Message m=new Message();
		m.setMesType(MessageType.message_comm_mes);
		m.setSender(mc.getSender());
		m.setGname(mc.getGname());
		m.setSname(mc.getSname());
		m.setGetter(mc.getGetter());
		m.setCon(jtf.getText());
		m.setSendTime(new java.util.Date().toString());
		showMessage(m);
		jtf.setText("");
		//���͸�������.
		try {
	//		JOptionPane.showMessageDialog(null, "�ͻ�����ʾ:"+m.getSender()+"Ҫ��"+m.getGetter()+"��Ϣ"+m.getCon());
	//		JOptionPane.showMessageDialog(null, m.getCon()+"��Ϣ����Ϊ:"+m.getMesType());
	//		JOptionPane.showMessageDialog(null, m.getCon()+"��Ϣ�ȸ�������");
			
			
			ObjectOutputStream oos=new ObjectOutputStream
					
			(Manage_ClientConServer_Thread.getClientConServerThread(m.getSender()).getS().getOutputStream());
			oos.writeObject(m);
		} catch (Exception e1) {
			e1.printStackTrace();
			// TODO: handle exception
		}
	}
	/**
	 * ��ʾ��Ϣ
	 * @param m
	 */
	public void showMessage(Message m)
	{
		//String info=m.getSender()+" �� "+m.getGetter()+" ˵:"+m.getCon()+"\r\n";
		String info2=m.getSname()+" : "+"\r\n"+"     "+m.getCon()+"\r\n";
		 //JOptionPane.showMessageDialog(null,m.getCon());
	//	this.jta.append(info);
		this.jta.append(info2);
	}
}
