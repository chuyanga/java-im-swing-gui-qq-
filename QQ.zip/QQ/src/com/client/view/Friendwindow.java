package com.client.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.border.EmptyBorder;

import com.client.tools.ManageQqChat;
import com.common.Message;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.UIManager;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JSpinner;
import javax.swing.JList;
import javax.swing.JTree;
import javax.swing.JEditorPane;
import javax.swing.JFormattedTextField;
import javax.swing.JSlider;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class Friendwindow extends JFrame{

	private JPanel contentPane;
    int xOld = 0;
    int yOld = 0;
    String owner;
    String sname;
    private JButton btnNewButton_1;
    private JTextField textField_1;
    private JLabel touxiang;
    private JLabel lblNewLabel_5;
    private JTextField textField;
    private JLabel lblNewLabel_1;
    private JLabel lblNewLabel_2;
    private JButton btnNewButton_2;
    private JTextPane textPane_2;
    private JLabel lblNewLabel_3;
    private JLabel jbs1;
    private JLabel jbs4;
    private JLabel jbs2;
    private JLabel jbs3;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Friendwindow frame = new Friendwindow("1", "1");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	//�������ߵĺ������
	public void upateFriend(Message m)
	{
		String onLineFriend[]=m.getCon().split(" ");
		
		for(int i=0;i<onLineFriend.length;i++)
		{
			
			//jb1s[Integer.parseInt(onLineFriend[i])-1].setEnabled(true);
			jbs1.setEnabled(true);
			jbs2.setEnabled(true);
			jbs3.setEnabled(true);
			jbs4.setEnabled(true);
			
		}
	}
	/**
	 * Create the frame.
	 * @param name 
	 * @param id 
	 */
	public Friendwindow(String id, String name) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setIconImage(new ImageIcon("image/qq.png").getImage());  
		   this.getContentPane().add(new JLabel("Just a test."));
		   this.setUndecorated(true); // ȥ�����ڵ�װ�� 
		   this.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
		   this.owner=id;
		   this.sname=name;
		  // jb1s =new JLabel[4];
		   //�����϶��¼�---ȥ��Ĭ�ϱ߿�󣬲����϶��ˣ�����ʵ������
	        this.addMouseListener(new MouseAdapter() {
	            @Override
	            public void mousePressed(MouseEvent e) {
	                xOld = e.getX();//��¼��갴��ʱ������
	                yOld = e.getY();
	            }
	        });

	        this.addMouseMotionListener(new MouseMotionAdapter() {
	            @Override
	            public void mouseDragged(MouseEvent e) {
	                int xOnScreen = e.getXOnScreen();
	                int yOnScreen = e.getYOnScreen();
	                int xx = xOnScreen - xOld;
	                int yy = yOnScreen - yOld;
	                Friendwindow.this.setLocation(xx, yy);//������ק�󣬴��ڵ�λ��
	            }
	        });
		   
		setBounds(100, 100, 339, 734);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(211, 211, 211));
		contentPane.setBackground(new Color(211, 211, 211));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel_3 = new JLabel("\u597D\u597D\u5B66\u4E60,\u5929\u5929\u5411\u4E0A");
		lblNewLabel_3.setFont(new Font("����", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(126, 110, 182, 31);
		contentPane.add(lblNewLabel_3);
		
		textPane_2 = new JTextPane();
		textPane_2.setText("\u7A7A\u95F4");
		textPane_2.setForeground(new Color(211, 211, 211));
		textPane_2.setFont(new Font("����", Font.BOLD, 18));
		textPane_2.setBackground(new Color(245, 245, 245));
		textPane_2.setBounds(281, 183, 57, 31);
		contentPane.add(textPane_2);
		
		JTextPane textPane_1_1 = new JTextPane();
		textPane_1_1.setText("\u8054\u7CFB\u4EBA");
		textPane_1_1.setForeground(new Color(128, 128, 128));
		textPane_1_1.setFont(new Font("����", Font.BOLD, 18));
		textPane_1_1.setBackground(new Color(245, 245, 245));
		textPane_1_1.setBounds(136, 183, 67, 31);
		contentPane.add(textPane_1_1);
		
		JTextPane textPane_1 = new JTextPane();
		textPane_1.setForeground(new Color(211, 211, 211));
		textPane_1.setBackground(new Color(245, 245, 245));
		textPane_1.setFont(new Font("����", Font.BOLD, 18));
		textPane_1.setText("\u6D88\u606F");
		textPane_1.setBounds(17, 183, 57, 31);
		contentPane.add(textPane_1);
		
		JTextPane textPane = new JTextPane();
		textPane.setBackground(new Color(245, 245, 245));
		textPane.setForeground(new Color(128, 128, 128));
		textPane.setFont(new Font("����", Font.BOLD, 16));
		textPane.setText("  \u597D\u53CB");
		textPane.setBounds(2, 219, 66, 31);
		contentPane.add(textPane);
		
		btnNewButton_2 = new JButton("\u7FA4\u804A");
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.setForeground(new Color(211, 211, 211));
		btnNewButton_2.setFont(new Font("����", Font.BOLD, 16));
		btnNewButton_2.setBackground(new Color(245, 245, 245));
		btnNewButton_2.setBounds(68, 216, 67, 38);
		contentPane.add(btnNewButton_2);
		
		
		textField = new JTextField();
		textField.setForeground(new Color(230, 230, 250));
		textField.setFont(new Font("������", Font.BOLD, 16));
		textField.setText("    \u641C\u7D22");
		textField.setBackground(new Color(0, 191, 255));
		textField.setBounds(2, 142, 340, 31);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
            	textFieldMouseEntered(evt);
            }
            
            public void mouseExited(java.awt.event.MouseEvent evt) {
            	textFieldMouseExited(evt);
            }
        });
		/**
		 * ��ʾ�ǳ�
		 */
		textField_1 = new JTextField();
		btnNewButton_2.setBorderPainted(false);
		textField_1.setFont(new Font("������", Font.BOLD, 18));
		textField_1.setText(name);
		textField_1.setBackground(new Color(0, 191, 255));
		textField_1.setBounds(136, 56, 137, 31);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		touxiang = new JLabel("New label");
		String ima="/image/im"+id+".png";
		touxiang.setIcon(new ImageIcon(Friendwindow.class.getResource(ima)));
		touxiang.setBounds(2, 44, 114, 101);
		contentPane.add(touxiang);
		
		lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/\u5934\u50CF\u5E95\u6846.png")));
		lblNewLabel_5.setBounds(118, 45, 220, 101);
		contentPane.add(lblNewLabel_5);
		
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/\u4E0A\u8FB9\u6846.png")));
		lblNewLabel.setBounds(1, 2, 270, 41);
		contentPane.add(lblNewLabel);
		
funs();
		// TODO �Զ����ɵķ������
		 btnNewButton = new JButton();
		 btnNewButton.setBorder(null);
		 btnNewButton.addMouseListener(new java.awt.event.MouseAdapter() {
		     public void mouseEntered(java.awt.event.MouseEvent evt) {
		         btnNewButtonMouseEntered(evt);
		     }
		     public void mouseExited(java.awt.event.MouseEvent evt) {
		         btnNewButtonMouseExited(evt);
		     }
		 });
		 btnNewButton.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
		     public void mouseMoved(java.awt.event.MouseEvent evt) {
		         btnNewButtonMouseMoved(evt);
		     }
		 });
		 
		 
		 
		 
		 btnNewButton.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		setExtendedState(JFrame.ICONIFIED);
		 	}
		 });
		 btnNewButton.setBorderPainted(false);
		 btnNewButton.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/7.png")));
		 btnNewButton.setBounds(269, 2, 39, 41);
		 contentPane.add(btnNewButton);
		 
		 lblNewLabel_1 = new JLabel("New label");
		 lblNewLabel_1.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/8.png")));
		 lblNewLabel_1.setBackground(new Color(220, 220, 220));
		 lblNewLabel_1.setBounds(2, 174, 336, 41);
		 contentPane.add(lblNewLabel_1);
		 
		 JPanel panel = new JPanel();
		 panel.setBackground(new Color(245, 245, 245));
		 panel.setBounds(2, 254, 336, 477);
		 contentPane.add(panel);
		 panel.setLayout(null);
		 
		 jbs4 = new JLabel("   \u5F90\u6D0B");
		 jbs4.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {	mouseClicked1(e);
		 	}
		 });
		 jbs4.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/ims4.png")));
		 jbs4.setFont(new Font("����", Font.BOLD, 13));
		 jbs4.setBackground(new Color(245, 245, 245));
		 jbs4.setBounds(2, 178, 326, 60);
		 panel.add(jbs4);
		 
		  jbs2 = new JLabel("   \u5C0F\u7EA2");
		 jbs2.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {	mouseClicked1(e);
		 	}
		 });
		 jbs2.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/ims2.png")));
		 jbs2.setFont(new Font("����", Font.BOLD, 13));
		 jbs2.setBackground(new Color(245, 245, 245));
		 jbs2.setBounds(2, 61, 326, 60);
		 panel.add(jbs2);
		 
		 jbs1 = new JLabel("   \u5218\u6D0B");
		 jbs1.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
				
			mouseClicked1(e);
			}
		 });
		 jbs1.setBounds(2, 0, 326, 60);
		 panel.add(jbs1);
		 jbs1.setBackground(new Color(245, 245, 245));
		 jbs1.setFont(new Font("����", Font.BOLD, 13));
		 jbs1.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/ims1.png")));
		 
		  jbs3 = new JLabel("   \u5C0F\u660E");
		 jbs3.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {	mouseClicked1(e);
		 	}
		 });
		 jbs3.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/ims3.png")));
		 jbs3.setFont(new Font("����", Font.BOLD, 13));
		 jbs3.setBackground(new Color(245, 245, 245));
		 jbs3.setBounds(2, 119, 326, 60);
		 panel.add(jbs3);
		 
		 lblNewLabel_2 = new JLabel("New label");
		 lblNewLabel_2.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/8.png")));
		 lblNewLabel_2.setBackground(new Color(220, 220, 220));
		 lblNewLabel_2.setBounds(2, 216, 336, 38);
		 contentPane.add(lblNewLabel_2);this.setLocationRelativeTo(null);//������ʾ
		
		
		

		
	}

	private void funs() {
		
		
		btnNewButton_1  = new JButton();
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
				// �رգ��˳����� 
			}
		});
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/�ر�.png")));
		btnNewButton_1.setBounds(305, 2, 33, 41);
		contentPane.add(btnNewButton_1);
		
		
		
		
		
		
		btnNewButton_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
            	btnNewButton_1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
            	btnNewButton_1MouseExited(evt);
            }
        });
		btnNewButton_1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
            	btnNewButton_1MouseMoved(evt);
            }
        });
	
		
	}
	protected void textFieldMouseExited(MouseEvent evt) {
		// TODO �Զ����ɵķ������
	
		String texts=textField.getText();
		if(texts==null||"".equals(texts)) {
		textField.setText("    \u641C\u7D22");
	}
	}

	protected void textFieldMouseEntered(MouseEvent evt) {
		// TODO �Զ����ɵķ������
		textField.setText("");
	}

	private void btnNewButtonMouseMoved(java.awt.event.MouseEvent evt) {
        // TODO add your handling code here:
//        btnNewButton.setBackground(Color.red);
    }

    private void btnNewButtonMouseEntered(java.awt.event.MouseEvent evt) {
        // TODO add your handling code here:
    	
    	btnNewButton.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/72.png")));
    }

    private void btnNewButtonMouseExited(java.awt.event.MouseEvent evt) {
        // TODO add your handling code here:
    	btnNewButton.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/7.png")));
    }

    private JButton btnNewButton;
    
    
	private void btnNewButton_1MouseMoved(java.awt.event.MouseEvent evt) {
        // TODO add your handling code here:
//        btnNewButton.setBackground(Color.red);
    }

    private void btnNewButton_1MouseEntered(java.awt.event.MouseEvent evt) {
        // TODO add your handling code here:
    	btnNewButton_1.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/6.png")));
    }

    private void btnNewButton_1MouseExited(java.awt.event.MouseEvent evt) {
        // TODO add your handling code here:
    	btnNewButton_1.setIcon(new ImageIcon(Friendwindow.class.getResource("/image/�ر�.png")));
    }



	public void mousePressed(MouseEvent e) {
		// TODO �Զ����ɵķ������
		
	}

	public void mouseReleased(MouseEvent e) {
		// TODO �Զ����ɵķ������
		
	}

	public void mouseEntered(MouseEvent e) {
		// TODO �Զ����ɵķ������
		
	}

	public void mouseExited(MouseEvent e) {
		// TODO �Զ����ɵķ������
		
	}

	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		
	}

	public void mouseClicked1(MouseEvent e) {
		// TODO �Զ����ɵķ������
		
		if(e.getClickCount()==2)
			{
				//�õ��ú��ѵı��
				String friendNo=((JLabel)e.getSource()).getText();
				
				String id;
				if(friendNo=="   ����") id="1";
				else if(friendNo=="   С��") id="2";
				else if(friendNo=="   С��") id="3";
				else id="4";
				System.out.println("��ϣ���� "+friendNo+" ����");
				//JOptionPane.showMessageDialog(null, "��ϣ���� "+id+" "+friendNo+" ����");
				Message m=new Message();
				m.setGetter(id);
				m.setGname(friendNo);
				m.setSender(this.owner);
				m.setSname(this.sname);
				//��������б��Ĺ��캯�������Լ���ID,���������ж����Ա����.�ڹ�������б���ʱ�������ֵjiu'n������ID
				Chat chat=new Chat(m);
				
				//�����������뵽������
				if(chat!=null) {
				ManageQqChat.addQqChat(this.owner+" "+id, chat);
				chat.setVisible(true);
				}
				else
					JOptionPane.showMessageDialog(null, "�Է�������");
			
			}
	}
}
