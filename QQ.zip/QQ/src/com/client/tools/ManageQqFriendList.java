/**
 * �������ѡ�������..������
 */
package com.client.tools;

import java.util.*;
import java.io.*;

import com.client.view.Friendwindow;
import com.client.view.*;
public class ManageQqFriendList {

	private static HashMap hm=new HashMap<String, Friendwindow>();
	
	public static void addQqFriendList(String qqid,Friendwindow qqFriendList){
		
		hm.put(qqid, qqFriendList);
	}
	
	public static Friendwindow getQqFriendList(String qqId)
	{
		return (Friendwindow)hm.get(qqId);
	}
}
