/**
 * �����û���Ϣ��
 */
package com.common;

public class User implements java.io.Serializable {
	 private static final long serialVersionUID = 4125096758372084309L;

	private String userId;
	private String passwd;
	private String name;
	private String phone;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public User() {
		super();
	}
	
	public User(String user_id,String user_password) {
		super();
		this.userId = user_id;
		
		this.passwd = user_password;
	}
	

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
}
