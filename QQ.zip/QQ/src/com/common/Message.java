package com.common;

public class Message implements java.io.Serializable{

	private String mesType;

	private String sender;
	private String getter;
	private String con;
	private String sendTime;
	private String sname;
	private String gname;
	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getGname() {
		return gname;
	}

	public void setGname(String gname) {
		this.gname = gname;
	}

	public Message(Message ms) {
		super();
		// TODO �Զ����ɵĹ��캯�����
		this.sender=ms.sender;
		this.getter=ms.getter;
		this.con=ms.con;
		this.sendTime=ms.sendTime;
		this.sname=ms.sname;
		this.gname=ms.gname;
	}

	public Message() {
		super();
		// TODO �Զ����ɵĹ��캯�����
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getGetter() {
		return getter;
	}

	public void setGetter(String getter) {
		this.getter = getter;
	}

	public String getCon() {
		return con;
	}

	public void setCon(String con) {
		this.con = con;
	}

	public String getSendTime() {
		return sendTime;
	}

	public void setSendTime(String sendTime) {
		this.sendTime = sendTime;
	}

	public String getMesType() {
		return mesType;
	}

	public void setMesType(String mesType) {
		this.mesType = mesType;
	}
}
